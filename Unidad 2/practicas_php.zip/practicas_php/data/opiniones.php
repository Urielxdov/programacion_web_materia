<?php exit; ?>
[
    {
        "fecha": "2026-10-20T08:39:44-06:00",
        "nombre": "archivo",
        "correo": "urieledgar878@gmail.com",
        "mensaje": "njksdnfds"
    }
]