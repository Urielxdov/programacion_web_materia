<?php exit; ?>
{
    "rojo": 1,
    "amarillo": 0,
    "morado": 0,
    "azul": 0
}